/* jshint
undef:true
*/
foo();
