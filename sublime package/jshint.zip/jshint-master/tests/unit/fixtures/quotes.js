// inconsistent quotation marks
var test1 = 'string';
var test2 = "string";