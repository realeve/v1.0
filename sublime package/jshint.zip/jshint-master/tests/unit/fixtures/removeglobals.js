JSON.somthing();
myglobal.somthing();
