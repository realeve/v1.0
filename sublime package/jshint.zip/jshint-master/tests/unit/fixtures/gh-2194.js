[ 'w','a','f','f','l','e','s','a','r','e','a','w','e','s','o','m','e' ].map(function(letter) {
  return letter;
});
